from clustering import getfinalimages

testfolder = "./testPatient"

getfinalimages(testfolder)
