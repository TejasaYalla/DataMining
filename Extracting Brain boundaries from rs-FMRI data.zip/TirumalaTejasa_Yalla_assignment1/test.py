from brainExtraction import filesforextraction

filesforextraction()
