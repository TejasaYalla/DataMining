import cv2
import numpy as np
import os
import shutil


def filesforextraction(path = os.getcwd()):
	checkFIELD = os.path.isdir(os.path.join(os.getcwd(),"Slices"))
	if checkFIELD:
		shutil.rmtree(os.path.join(os.getcwd(),"Slices"))
	checkFIELD = os.path.isdir(os.path.join(os.getcwd(),"Boundaries"))
	if checkFIELD:
		shutil.rmtree(os.path.join(os.getcwd(),"Boundaries"))
	for file in os.listdir(os.path.join(path,"PatientData","Data")):
		# From the list selecting only image names ending having thresh
		if("thresh" in file ):
			Slices_and_Boundaries(os.path.join(path,"PatientData","Data"),file)


def get_rect_with_r(cnts,file_name,image_path):
	# Delimiter to name images
	indexnumber = 0
	image = cv2.imread(os.path.join(image_path,file_name))
	X_1, Y_1, W_1, H_1 = cv2.boundingRect(cnts[len(cnts)-1])
	for i in range(1,len(cnts)):
		X_2, Y_2, W_1, H_1 = cv2.boundingRect(cnts[len(cnts)-i-1])
		if(Y_2 != Y_1 and abs(Y_2-Y_1) > W_1):
			break

	for i in range(1,len(cnts)):
		X_3, Y_3, W_1, H_1 = cv2.boundingRect(cnts[len(cnts)-i-1])
		if(X_3 != X_1 and abs(X_3-X_1) > H_1):
			break
	x_limit, y_limit, W_1, H_1 = cv2.boundingRect(cnts[-1])
	wsm =  X_3-X_1
	hsm = Y_2 - Y_1
	image = cv2.imread(os.path.join(image_path,file_name))
	for i in range(0,len(cnts)):
		c = cnts[len(cnts) - i-1]
		X_1, Y_1, W_1, H_1 = cv2.boundingRect(c)
		X_2 = X_1+wsm-W_1
		Y_2 = Y_1-hsm
		X_1 = X_1 + W_1+W_1
		Y_1 = Y_1 + H_1
		if(X_1 < x_limit or Y_2 < y_limit):
			continue
		new_img = image[Y_2:Y_1, X_1:X_2]	
		gray=cv2.cvtColor(new_img,cv2.COLOR_BGR2GRAY)
		thresh=cv2.inRange(gray,0,25)
		edged = cv2.Canny(thresh, 50, 100)
		(cnt, _) = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		if(len(cnt)):
        		new_img = image[Y_2:Y_1, X_1:X_2]
        		cv2.imwrite(os.path.join(os.path.join(os.getcwd(),"Slices"),file_name.split('.')[0])+'/'+str(indexnumber) +'.png', new_img)
        		cv2.drawContours(new_img, cnt, -1, (0,255,0), 1)
        		cv2.imwrite(os.path.join(os.path.join(os.getcwd(),"Boundaries"),file_name.split('.')[0])+'/'+str(indexnumber) +'.png', new_img)

		else:
			continue
		indexnumber = indexnumber + 1



def Slices_and_Boundaries(image_path,file_name):
	checkFIELD = os.path.isdir(os.path.join(os.getcwd(),"Slices"))
	if not checkFIELD:
		os.mkdir(os.path.join(os.getcwd(),"Slices"))
	checkFIELD = os.path.isdir(os.path.join(os.path.join(os.getcwd(),"Slices"),file_name.split('.')[0]))
	if not checkFIELD:
		os.mkdir(os.path.join(os.path.join(os.getcwd(),"Slices"),file_name.split('.')[0]))
	checkFIELD = os.path.isdir(os.path.join(os.getcwd(),"Boundaries"))
	if not checkFIELD:
		os.mkdir(os.path.join(os.getcwd(),"Boundaries"))
	checkFIELD = os.path.isdir(os.path.join(os.path.join(os.getcwd(),"Boundaries"),file_name.split('.')[0]))
	if not checkFIELD:
		os.mkdir(os.path.join(os.path.join(os.getcwd(),"Boundaries"),file_name.split('.')[0]))
	image = cv2.imread(os.path.join(image_path,file_name))
	cnt_image = cv2.imread(os.path.join(image_path,file_name))
	gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
	thresh=cv2.inRange(gray,255,255)
	edged = cv2.Canny(thresh, 255, 255)
	(cnts, _) = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
	get_rect_with_r(cnts, file_name,image_path)



